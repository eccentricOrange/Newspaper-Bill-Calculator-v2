Free License  - Kate : icon1.png, icon3.png
